<?php
include 'logged.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blogs Page</title>
    <link rel="stylesheet" href="blogs_style.css">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
    <!-- Header -->
    <header class="header">
        <div class="header_left">
            <div class="your_mail">
                <p><i class="fa fa-share" aria-hidden="true"></i>shopmail@gmail.com</p>
            </div>
            <div class="header_icon">
                <p><i class="fa fa-facebook" aria-hidden="true"></i></p>
                <p><i class="fa fa-twitter" aria-hidden="true"></i></p>
                <p><i class="fa fa-instagram" aria-hidden="true"></i></p>
                <p><i class="fa fa-whatsapp" aria-hidden="true"></i></p>
            </div>
        </div>
        <form class="header_button">
                <button class="order_button" formaction="order.php">Order Medicine</button>
                <button class="doctor_button" formaction="appoinment.php">Make An Appoinment</button>
        </form>
    </header>
<!--
        <div class="alertation_success" id="fav">
        <div class="alert_note">
            <strong></strong> 
            <button onclick="myfn()">X</button>
        </div> 
</div>-->


<!-- Nevigation Bar -->
<nav class="navbar">
    <div class="nav-left">
        <ul>
            <li><a href="index2.php">HOME</a></li>
            <li><a href="order.php">ORDER</a></li>
            <li><a href="doctors.php">DOCTORS</a></li>
            <li><a href="appoinment.php">APPOINMENT</a></li> 
            <li class="more active"><a href="#">MORE</a>
                <ul>
                    <li><a href="about.php">ABOUT</a></li>
                    <li><a href="gallery.php">GALLERY</a></li>
                    <li><a href="blogs.php">BLOGS</a></li>
                    <li><a href="contact.php">CONTACT US</a></li>
                </ul>
            </li> 
        </ul>
    </div>
    <div class="container h-100">
        <div class="d-flex justify-content-center h-100 search-box">
          <div class="searchbar">
            <input class="search_input" type="text" name="" placeholder="Search here..."/>
            <a href="#" class="search_icon"><i class="fa fa-search"></i></a>
          </div>
        </div>
      </div>
<div class="nav-right">
    <div class="login_signup">
    <ul>
        <?php
            if(!$loggedin){
                echo
                '<li id="login-btn">Login</li> |
                <li id="signup-btn">Sign Up</li>';
            }
            if($loggedin){
                echo '<li><i class="fa fa-user" aria-hidden="true"></i></li>
                    <li>'.$_SESSION['username'].'</li> |
                    <li><a href="logout.php">Logout</a></li>';
            }
   
            ?>
        </ul>
    </div>
    <form class="offer">
        <button class="offer" formaction="offer.php">OFFER</button>
    </form>

    <div class="help">
        <span><a href="need_help.php">NEED HELP?</a></span>
    </div>
</div>
</nav>


<!-- login Form-->
<div class="login-form-container" id="login-form-container">
    <i id="close-login-btn" class="fa fa-times"></i>
    <form action="login.php" method="post" autocomplete="on">
        <h3>For Login</h3>
        <span>Email</span>
        <input type="text" name="email" class="box" placeholder="Enter your ph no/email" id="email" required>
        <span>Password</span>
        <input type="password" name="password" class="box" placeholder="Enter your password" id="password" required>
        <button type="submit" name="submit" class="btn" >Login Here</button>     
        <p>forget password? <a id="forget">click here</a></p>
        <p>don't have an account? <a id="login-to-signup">create new one</a></p>
    </form>
</div>


<!-- signup Form-->
<div class="signup-form-container" id="signup-form-container">
    <i id="close-signup-btn" class="fa fa-times"></i>
    <form action="signup.php" method="post" autocomplete="on">
        <h3>Register Form</h3>
        <span>Username</span>
        <input type="text" name="username" class="box" placeholder="Enter your username" id="username" required>
        <span>Phone No./WhatsApp No.</span>
        <input type="tel" name="phone" class="box" placeholder="Enter your phone no." id="phone" required>
        <span>Email Id</span>
        <input type="email" name="email" class="box" placeholder="Enter your email" id="email" required>
        <span>Password</span>
        <input type="password" name="password" class="box" placeholder="Enter your password" id="password" required>
        <button type="submit" class="btn" id="signup-btn-close">Sign Up now</button>     
        <p>You have an account? <a id="signup-to-login">Login first</a></p>
    </form>
</div>
    <!-- Shop details -->
    <div class="shop_details">
        <div class="shop_logo"><img src="img/logo.jpeg" alt="Shop Logo"></div>
        <div class="free_call">
            <div class="details_icon"><i class="fa fa-phone" aria-hidden="true"></i></div>
            <div class="details_content">
                <p><span style="color: #4091FF;">Free Call</span> +1 234 456 78910</p>
                <p>Call Us Now 24/7 Customer Support</p>
            </div>
        </div>
        <div class="location">
            <div class="details_icon"><i class="fa fa-location-arrow" aria-hidden="true"></i></div>
            <div class="details_content">
                <p>Our Location</p>
                <p>198 West 21th Street, <br>Suite 721 New York NY 10016</p>
            </div>
        </div>
        <div class="timing">
            <div class="details_icon"><i class="fa fa-clock-o" aria-hidden="true"></i></div>
            <div class="details_content">
                <p>Opening Timing</p>
                <p>Morning: 8am - 2pm<br>Evening: 5pm - 11pm</p>
            </div>
        </div>
    </div>

<!--All blogs-->
<section class="blogs" id="blogs">
    <h1 class="blogs_heading">All Blog Updates</h1>
    <div class="box-container">
        <div class="box">
            <img src="img/home_slide_background_1.jpg" alt="">
            <div class="content">
                <div class="icons">
                    <a href="#"><i class="fa fa-user" aria-hidden="true"></i> by user </a>
                    <a href="#"><i class="fa fa-calendar" aria-hidden="true"></i> 1st may, 2021 </a>
                </div>
                <h3>All time service available</h3>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Veniam, expedita.</p>
                <a href="#" class="btn">read more</a>
            </div>
        </div>
        <div class="box">
            <img src="img/home_slide_background_2.jpg" alt="">
            <div class="content">
                <div class="icons">
                    <a href="#"><i class="fa fa-user" aria-hidden="true"></i> by user </a>
                    <a href="#"><i class="fa fa-calendar" aria-hidden="true"></i> 1st may, 2021 </a>
                </div>
                <h3>Best doctors</h3>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Veniam, expedita.</p>
                <a href="#" class="btn">read more</a>
            </div>
        </div>
        <div class="box">
            <img src="img/home_slide_background_3.jpg" alt="">
            <div class="content">
                <div class="icons">
                    <a href="#"><i class="fa fa-user" aria-hidden="true"></i> by user </a>
                    <a href="#"><i class="fa fa-calendar" aria-hidden="true"></i> 1st may, 2021 </a>
                </div>
                <h3>Good customer services</h3>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Veniam, expedita.</p>
                <a href="#" class="btn">read more</a>
            </div>
        </div>
    </div>
    <div class="box-container">
        <div class="box">
            <img src="img/home_slide_background_1.jpg" alt="">
            <div class="content">
                <div class="icons">
                    <a href="#"><i class="fa fa-user" aria-hidden="true"></i> by user </a>
                    <a href="#"><i class="fa fa-calendar" aria-hidden="true"></i> 1st may, 2021 </a>
                </div>
                <h3>All time service available</h3>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Veniam, expedita.</p>
                <a href="#" class="btn">read more</a>
            </div>
        </div>
            <div class="box">
                <img src="img/home_slide_background_2.jpg" alt="">
                <div class="content">
                    <div class="icons">
                        <a href="#"><i class="fa fa-user" aria-hidden="true"></i> by user </a>
                        <a href="#"><i class="fa fa-calendar" aria-hidden="true"></i> 1st may, 2021 </a>
                    </div>
                    <h3>Best doctors</h3>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Veniam, expedita.</p>
                    <a href="#" class="btn">read more</a>
                </div>
            </div>
            <div class="box">
                <img src="img/home_slide_background_3.jpg" alt="">
                <div class="content">
                    <div class="icons">
                        <a href="#"><i class="fa fa-user" aria-hidden="true"></i> by user </a>
                        <a href="#"><i class="fa fa-calendar" aria-hidden="true"></i> 1st may, 2021 </a>
                    </div>
                    <h3>Good customer services</h3>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Veniam, expedita.</p>
                    <a href="#" class="btn">read more</a>
                </div>
            </div>
        </div>
        
    <div class="box-container">
        <div class="box">
            <img src="img/home_slide_background_1.jpg" alt="">
            <div class="content">
                <div class="icons">
                    <a href="#"><i class="fa fa-user" aria-hidden="true"></i> by user </a>
                    <a href="#"><i class="fa fa-calendar" aria-hidden="true"></i> 1st may, 2021 </a>
                </div>
                <h3>All time service available</h3>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Veniam, expedita.</p>
                <a href="#" class="btn">read more</a>
            </div>
        </div>
            <div class="box">
                <img src="img/home_slide_background_2.jpg" alt="">
                <div class="content">
                    <div class="icons">
                        <a href="#"><i class="fa fa-user" aria-hidden="true"></i> by user </a>
                        <a href="#"><i class="fa fa-calendar" aria-hidden="true"></i> 1st may, 2021 </a>
                    </div>
                    <h3>Best doctors</h3>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Veniam, expedita.</p>
                    <a href="#" class="btn">read more</a>
                </div>
            </div>
            <div class="box">
                <img src="img/home_slide_background_3.jpg" alt="">
                <div class="content">
                    <div class="icons">
                        <a href="#"><i class="fa fa-user" aria-hidden="true"></i> by user </a>
                        <a href="#"><i class="fa fa-calendar" aria-hidden="true"></i> 1st may, 2021 </a>
                    </div>
                    <h3>Good customer services</h3>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Veniam, expedita.</p>
                    <a href="#" class="btn">read more</a>
                </div>
            </div>
        </div>
     </section>

     <script src="script.js"></script>
</body>
</html>