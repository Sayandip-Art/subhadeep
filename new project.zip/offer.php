<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Offer Page</title>
    <link rel="stylesheet" href="offer_style.css">
</head>
<body>
    <div class="banner-container">

        <div class="banner">
            <div class="content">
                <div>
                    <img src="img/offer1.png" alt="">
                </div>
                <div>
                    <span>upto</span>
                    <h3>10% 0ff</h3>
                    <p>offer ends after 5 days</p>
                </div>
                <div>
                    <img src="img/offer2.png" alt="">
                </div>
            </div>
        </div>
    
    </div>
</body>
</html>