
<?php 

include 'dbconnect.php';

session_start();
//include 'logged.php';
//error_reporting(0);
/*
if(isset($_SESSION['loggedin']) && $_SESSION['loggedin']==true){
    header("Location: welcome.php");
}*/
if (isset($_SESSION['username'])) {
	header("Location: welcome.php");
}/*
if (isset($_POST['submit'])) {
	$email = $_POST['email'];
	$password = $_POST['password'];
	if (password_verify($password, $row['password'])){ 
	$sql = "SELECT * FROM signup WHERE email='$email' AND password='$password'";
	$result = mysqli_query($conn, $sql);
	if ($result->num_rows > 0) {
		$row = mysqli_fetch_assoc($result);
		$_SESSION['loggedin'] = true;
		$_SESSION['username'] = $row['username'];
        $_SESSION['email']=$row['email'];
        $_SESSION['phone']=$row['phone'];
        $_SESSION['password']=$row['password'];
		header("Location: welcome.php");
	} 
	else {
		echo "<script>alert('Something went wrong...')</script>";
	}
}

/*

$email = $_POST['email'];
$password = $_POST['password'];

$var = "SELECT * FROM signup WHERE email='$email' AND password='$password'";
$query = mysqli_query($conn,$var);

if(mysqli_num_rows($query)){
    header("location: welcome.php?msg=Done");
}
else {
    header("location: login.html?msg=Not Done");
}*/

  
  // $sql = "Select * from users where username='$username' AND password='$password'";
  if (isset($_POST['submit'])) {
	$email = $_POST['email'];
	$password = $_POST['password'];
    $sql = "Select * from signup where email='$email'";
    $result = mysqli_query($conn, $sql);
    //$num = mysqli_num_rows($result);
    if ($result->num_rows > 0) {
        	$row=mysqli_fetch_assoc($result))
            if (password_verify($password, $row['password'])){ 
				$_SESSION['loggedin'] = true;
				$_SESSION['username'] = $row['username'];
				$_SESSION['email']=$row['email'];
				$_SESSION['phone']=$row['phone'];
			//	$_SESSION['password']=$row['password'];
				header("Location: welcome.php");
            } 
            else{
                echo "<script>alert('Password was not matched...')</script>";
            }
        }
    
    else{
        echo "<script>alert('Something went wrong...')</script>";
    }
}
?>