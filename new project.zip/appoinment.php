
<?php
 //include auth_session.php file on all user panel pages
 include("auth_session.php");
 //include 'logged.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Appoinment Form</title>
    <link rel="stylesheet" href="appoinment_style.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    
    <!-- Header -->
    <header class="header">
        <div class="header_left">
            <div class="your_mail">
                <p><i class="fa fa-share" aria-hidden="true"></i>shopmail@gmail.com</p>
            </div>
            <div class="header_icon">
                <p><i class="fa fa-facebook" aria-hidden="true"></i></p>
                <p><i class="fa fa-twitter" aria-hidden="true"></i></p>
                <p><i class="fa fa-instagram" aria-hidden="true"></i></p>
                <p><i class="fa fa-whatsapp" aria-hidden="true"></i></p>
            </div>
        </div>
        <form class="header_button">
                <button class="order_button" formaction="order.php">Order Medicine</button>
                <button class="doctor_button" formaction="appoinment.php">Make An Appoinment</button>
        </form>
    </header>

<!-- Nevigation Bar -->
<nav class="navbar">
    <div class="nav-left">
        <ul>
            <li><a href="index2.php">HOME</a></li>
            <li><a href="order.php">ORDER</a></li>
            <li><a href="doctors.php">DOCTORS</a></li>
            <li class="active"><a href="appoinment.php">APPOINMENT</a></li> 
            <li class="more"><a href="#">MORE</a>
                <ul>
                    <li><a href="about.php">ABOUT</a></li>
                    <li><a href="gallery.php">GALLERY</a></li>
                    <li><a href="blogs.php">BLOGS</a></li>
                    <li><a href="contact.php">CONTACT US</a></li>
                </ul>
            </li> 
        </ul>
    </div>
    <div class="container h-100">
        <div class="d-flex justify-content-center h-100 search-box">
          <div class="searchbar">
            <input class="search_input" type="text" name="" placeholder="Search here..."/>
            <a href="#" class="search_icon"><i class="fa fa-search"></i></a>
          </div>
        </div>
      </div>
<div class="nav-right">
    <div class="login_signup">
    <ul>
        <?php
                echo '<li><i class="fa fa-user" aria-hidden="true"></i></li>
                    <li>'.$_SESSION['username'].'</li> |
                    <li><a href="logout.php">Logout</a></li>';
            
            ?>
        </ul>
    </div>
    <form class="offer">
        <button class="offer" formaction="offer.php">OFFER</button>
    </form>
 
    <div class="help">
        <span><a href="need_help.php">NEED HELP?</a></span>
    </div>
</div>
</nav>



    <!-- Shop details -->
    <div class="shop_details">
        <div class="shop_logo"><img src="img/logo.jpeg" alt="Shop Logo"></div>
        <div class="free_call">
            <div class="details_icon"><i class="fa fa-phone" aria-hidden="true"></i></div>
            <div class="details_content">
                <p><span style="color: #4091FF;">Free Call</span> +1 234 456 78910</p>
                <p>Call Us Now 24/7 Customer Support</p>
            </div>
        </div>
        <div class="location">
            <div class="details_icon"><i class="fa fa-location-arrow" aria-hidden="true"></i></div>
            <div class="details_content">
                <p>Our Location</p>
                <p>198 West 21th Street, <br>Suite 721 New York NY 10016</p>
            </div>
        </div>
        <div class="timing">
            <div class="details_icon"><i class="fa fa-clock-o" aria-hidden="true"></i></div>
            <div class="details_content">
                <p>Opening Timing</p>
                <p>Morning: 8am - 2pm<br>Evening: 5pm - 11pm</p>
            </div>
        </div>
    </div>

    
<!--Doctors-->
<div class="app">
    <h1 class="appoin_heading">Doctor Appoinment</h1>    
    <div class="main_section">
        <div class="image"><img src="img/home_1.jpg" alt=""></div>
        <div class="appoint">
            <p class="heading">Appoinment Form</p>
            <p class="content">A small river named Duden flows by their place and supplies it with the necessary regelialia. 
                It is a paradisematic country, in which roasted parts of sentences fly into your mouth. 
                It is a paradisematic country, in which roasted parts of sentences fly into your mouth.
                If you are old patients, then choose <strong>OLD</strong>, otherwise choose <strong>NEW</strong>.
            </p>
            <form class="ptype_choose">
                <strong>PATIENT'S TYPE : </strong>
                <button type="submit" formaction="appoinment(old).php" class="old_btn">OLD</button>
                <button type="submit" formaction="appoinment(new).php" class="new_btn">NEW</button>
            </form> 
            <p class="content">After choose the patient type, then go to the <strong>Next step...</strong></p>
        </div>
    </div>
</div>
    
    <!-- End Section -->
    <section class="footer">
        <table>
            <tr>
                <td><img src="img/logo.jpeg" alt="Shop Logo"></td>
                <td>Departments</td>
                <td>Link</td>
                <td>Facilities</td>
                <td>Have A Question?</td>
            </tr>
            <tr>
                <td>Far far away, behind the</td>
                <td><i class="fa fa-angle-right" aria-hidden="true"></i><span>Neurology</span></td>
                <td><i class="fa fa-angle-right" aria-hidden="true"></i><span><a href="#">Home</a></span></td>
                <td><i class="fa fa-angle-right" aria-hidden="true"></i><span>Emergency Help</span></td>
                <td><i class="fa fa-map-marker" aria-hidden="true"></i><span>203 Fake St. Mountain</span></td>
            </tr>
            <tr>
                <td>word mountains, far from</td>
                <td><i class="fa fa-angle-right" aria-hidden="true"></i><span>Ophthalmology</span></td>
                <td><i class="fa fa-angle-right" aria-hidden="true"></i><span><a href="about.php">About</a></span></td>
                <td><i class="fa fa-angle-right" aria-hidden="true"></i><span>Qualified Doctors</span></td>
                <td><span></span><span>View, San Francisco,</span></td>
            </tr>
            <tr>
                <td>the countries.</td>
                <td><i class="fa fa-angle-right" aria-hidden="true"></i><span>Neuclear Magnetic</span></td>
                <td><i class="fa fa-angle-right" aria-hidden="true"></i><span><a href="department.php">Departments</a></span></td>
                <td><i class="fa fa-angle-right" aria-hidden="true"></i><span>Location & Direction</span></td>
                <td><span></span><span>California, USA</span></td>
            </tr>
            <tr>
                <td></td>
                <td><i class="fa fa-angle-right" aria-hidden="true"></i><span>X-Ray</span></td>
                <td><i class="fa fa-angle-right" aria-hidden="true"></i><span><a href="doctors.php">Doctors</a></span></td>
                <td><i class="fa fa-angle-right" aria-hidden="true"></i><span>Order Medicine</span></td>
                <td></td>
            </tr>
            <tr>
                <td class="social_icons">
                    <a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a>
                    <a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                    <a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a>
                    <a href="#"><i class="fa fa-snapchat-ghost" aria-hidden="true"></i></a>
                </td>
                <td><i class="fa fa-angle-right" aria-hidden="true"></i><span>Surgical</span></td>
                <td><i class="fa fa-angle-right" aria-hidden="true"></i><span><a href="blogs.php">Blogs</a></span></td>
                <td><i class="fa fa-angle-right" aria-hidden="true"></i><span>Secure Paymnet</span></td>
                <td><i class="fa fa-phone" aria-hidden="true"></i><span style="color:#4091FF;">+91 1234567890</span></td>
            </tr>
            <tr>
                <td></td>
                <td><i class="fa fa-angle-right" aria-hidden="true"></i><span>Cardiology</span></td>
                <td><i class="fa fa-angle-right" aria-hidden="true"></i><span><a href="appoinment.php">Appoinments</a></span></td>
                <td><i class="fa fa-angle-right" aria-hidden="true"></i><span>Stored Safely</span></td>
                <td><i class="fa fa-envelope" aria-hidden="true"></i><span><a href="#">yourmail.com@gmail.com</a></span></td>
            </tr>
            <tr>
                <td></td>
                <td><i class="fa fa-angle-right" aria-hidden="true"></i><span>Dental</span></td>
                <td><i class="fa fa-angle-right" aria-hidden="true"></i><span><a href="gallery.php">Gallery</a></span></td>
                <td></td>
                <td></td>
            </tr>
        </table>
    </section>

    <!-- Footer -->
    <footer class="copy_right">
        <p>Copyright ©2021 All rights reserved</p>
    </footer>
    <script src="script.js"></script>
</body>
</html>
