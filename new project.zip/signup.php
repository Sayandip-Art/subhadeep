<?php
/*
    require('dbconnect.php');
    // When form submitted, insert values into the database.
    if (isset($_REQUEST['username'])) {
        // removes backslashes
        $username = stripslashes($_REQUEST['username']);
        //escapes special characters in a string
        $username = mysqli_real_escape_string($conn, $username);
        $phone    = stripslashes($_REQUEST['phone']);
        $phone    = mysqli_real_escape_string($conn, $phone);
        $email    = stripslashes($_REQUEST['email']);
        $email    = mysqli_real_escape_string($conn, $email);
        $password = stripslashes($_REQUEST['password']);
        $password = mysqli_real_escape_string($conn, $password);
        $query    = "INSERT into `signup` (username, phone, email, password, date)
                     VALUES ('$username', '$phone','$email','$password',  	current_timestamp()	)";
        $result   = mysqli_query($conn, $query);
        if ($result) {
            echo "<div class='form'>
                  <h3>You are registered successfully.</h3><br/>
                  <p class='link'>Click here to <a href='index4.php'>homepage</a></p>
                  </div>";
        } else {
            echo "<div class='form'>
                  <h3>Required fields are missing.</h3><br/>
                  <p class='link'>Click here to <a href='signup.html'>signup</a> again.</p>
                  </div>";
        }
        $hash = password_hash($password, PASSWORD_DEFAULT);
         $sql = "INSERT INTO `users` ( `username`, `password`, `dt`) VALUES ('$username', '$hash', current_timestamp())";
    } */

    include 'dbconnect.php';
    error_reporting(0);
    session_start();
    if (isset($_SESSION['username'])) {
        header("Location: welcome.php");
    }
if($_SERVER["REQUEST_METHOD"] == "POST"){
    $username = $_POST["username"];
    $phone = $_POST["phone"];
    $email = $_POST["email"];
    $password =$_POST["password"];
    $sql = "SELECT * FROM signup WHERE phone='$phone' AND email='$email'";
    $checksign = mysqli_query($conn, $sql);
    if (!$checksign->num_rows > 0) {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $sql = "INSERT INTO `signup` (username, phone, email, password, date) VALUES ('$username', '$phone', '$email', '$hash', current_timestamp());";
        $resultsign = mysqli_query($conn, $sql);
        if ($resultsign){
            echo "<script>alert('Your are successfully registered...')</script>";
                  header("Location: index2.php");
        }
        else{
            echo "<script>alert('Something went wrong...')</script>";
        }
    }
    else{
        echo "<script>alert('You have been already registered...')</script>";
    }  
}
?>