<?php
    session_start();
    if(!isset($_SESSION["username"])) {
        header("Location: index2.php");
     // echo "<script>alert('You are exixting user, please login...')</script>";
        exit();
    }
?>